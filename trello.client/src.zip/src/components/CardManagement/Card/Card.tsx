import React, { useState, useEffect } from 'react';
import './Card.css';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faTrash } from '@fortawesome/free-solid-svg-icons';

interface Comment {
    id: string;
    comment: string;
    uid: string;
}

interface CardProps {
    id: string;
    title: string;
    description: string;
    onDeleteCard: () => void;
    onSaveCard: (id: string, title: string, description: string) => void;
    onEditCard: () => void;
    isEditing: boolean;
}

const Card: React.FC<CardProps> = ({
    id,
    title,
    description,
    onDeleteCard,
    onSaveCard,
    onEditCard,
    isEditing,
}) => {
    const [editTitle, setEditTitle] = useState(title);
    const [editDescription, setEditDescription] = useState(description);
    const [comments, setComments] = useState<Comment[]>([]);
    const [newComment, setNewComment] = useState('');

    useEffect(() => {
        if (isEditing) {
            // Simula il caricamento dei commenti
            const loadComments = () => {
                const mockComments: Comment[] = [
                    { id: 'comment_1', comment: 'Questo � un commento', uid: 'user_1' },
                    { id: 'comment_2', comment: 'Questo � un altro commento', uid: 'user_2' }
                ];
                setComments(mockComments);
            };

            loadComments();
        }
    }, [isEditing]);

    const handleAddComment = () => {
        if (newComment.trim()) {
            const newCommentObj = { id: `comment_${new Date().getTime()}`, comment: newComment, uid: 'current_user' };
            setComments([...comments, newCommentObj]);
            setNewComment('');
        }
    };

    const handleDeleteComment = (commentId: string) => {
        setComments(comments.filter(comment => comment.id !== commentId));
    };

    const handleSaveCard = () => {
        onSaveCard(id, editTitle, editDescription);
        onEditCard(); // Chiude il modal
    };

    return (
        <div className="card">
            <div className="card-content" onClick={onEditCard}>
                <h4>{title}</h4>
                <p>{description}</p>
            </div>
            <FontAwesomeIcon icon={faTrash} className="delete-icon" onClick={(e) => { e.stopPropagation(); onDeleteCard(); }} />
            {isEditing && (
                <div className="modal">
                    <div className="modal-content" onClick={(e) => e.stopPropagation()}>
                        <h4>Modifica Card</h4>
                        <input
                            type="text"
                            value={editTitle}
                            onChange={(e) => setEditTitle(e.target.value)}
                            placeholder="Titolo"
                        />
                        <textarea
                            value={editDescription}
                            onChange={(e) => setEditDescription(e.target.value)}
                            placeholder="Descrizione"
                        />
                        <div className="comments-section">
                            {comments.map(comment => (
                                <div key={comment.id} className="comment">
                                    {comment.comment}
                                    <FontAwesomeIcon icon={faTrash} className="delete-comment-icon" onClick={() => handleDeleteComment(comment.id)} />
                                </div>
                            ))}
                            <div className="add-comment">
                                <textarea
                                    value={newComment}
                                    onChange={(e) => setNewComment(e.target.value)}
                                    placeholder="Aggiungi un commento..."
                                    className="comment-textarea"
                                />
                                <button onClick={handleAddComment} className="add-comment-button">Conferma</button>
                            </div>
                        </div>
                        <div className="modal-buttons">
                            <button onClick={handleSaveCard} className="modal-button save-button">Conferma</button>
                            <button onClick={onEditCard} className="modal-button cancel-button">Annulla</button>
                        </div>
                    </div>
                </div>
            )}
        </div>
    );
};

export default Card;
