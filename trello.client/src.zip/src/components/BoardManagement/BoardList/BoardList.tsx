import React from 'react';
import './BoardList.css';

const BoardList: React.FC = () => {
    return (
        <div className="board-list-container">
            {/* Qui verranno visualizzate le board disponibili */}
        </div>
    );
};

export default BoardList;
