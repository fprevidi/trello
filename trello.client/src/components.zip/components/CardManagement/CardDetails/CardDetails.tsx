import React from 'react';
import './CardDetails.css';

const CardDetails: React.FC = () => {
    return (
        <div className="card-details-container">
            {/* Dettagli della card */}
        </div>
    );
};

export default CardDetails;
