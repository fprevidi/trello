import React, { useState, useEffect } from 'react';
import { useParams } from 'react-router-dom';
import './Board.css';
import List from '../../ListManagement/List/List';
import { DragDropContext, DropResult } from 'react-beautiful-dnd';
import { v4 as uuidv4 } from 'uuid';

interface Card {
    uid: string;
    title: string;
    description: string;
}

interface BoardList {
    uid: string;
    name: string;
    cards: Card[];
}

const Board: React.FC = () => {
    const { uid } = useParams<{ uid: string }>();
    const [lists, setLists] = useState<BoardList[]>([]);
    const [isModalOpen, setIsModalOpen] = useState(false);
    const [newListTitle, setNewListTitle] = useState('');
    const [isDragging, setIsDragging] = useState(false);

    useEffect(() => {
        const fetchBoardData = async (uid: string) => {
            try {
                const token = localStorage.getItem('token');
                const response = await fetch(`/api/GetLists/${uid}`, {
                    headers: {
                        'Authorization': `Bearer ${token}`
                    }
                });
                if (!response.ok) {
                    throw new Error('Network response was not ok');
                }
                const data = await response.json();

                const listsWithCards = data.map((list: BoardList) => ({
                    ...list,
                    cards: list.cards || []
                }));

                setLists(listsWithCards);
            } catch (error) {
                console.error('Error fetching lists:', error);
            }
        };

        if (uid && !isDragging) {
            fetchBoardData(uid);
        }
    }, [uid, isDragging]);

    const handleAddList = () => {
        if (newListTitle.trim() && !lists.some(list => list.name === newListTitle)) {
            const newList: BoardList = {
                uid: uuidv4(),
                name: newListTitle,
                cards: []
            };
            setLists([...lists, newList]);
            setNewListTitle('');
            setIsModalOpen(false);
        }
    };

    const handleAddCard = (listUid: string, title: string, description: string) => {
        const newCard: Card = {
            uid: uuidv4(),
            title,
            description
        };
        setLists(lists.map(list =>
            list.uid === listUid ? { ...list, cards: [...list.cards, newCard] } : list
        ));
    };

    const handleEditCard = (listUid: string, cardUid: string, title: string, description: string) => {
        setLists(lists.map(list =>
            list.uid === listUid ? {
                ...list,
                cards: list.cards.map(card => card.uid === cardUid ? { ...card, title, description } : card)
            } : list
        ));
    };

    const handleDeleteCard = (listUid: string, cardUid: string) => {
        setLists(lists.map(list =>
            list.uid === listUid ? {
                ...list,
                cards: list.cards.filter(card => card.uid !== cardUid)
            } : list
        ));
    };

    const onDragStart = () => {
        setIsDragging(true);
    };

    const onDragEnd = (result: DropResult) => {
        setIsDragging(false);

        const { source, destination } = result;

        if (!destination) {
            return;
        }

        if (source.droppableId === destination.droppableId && source.index === destination.index) {
            return;
        }

        const sourceListIndex = lists.findIndex(list => list.uid === source.droppableId);
        const destinationListIndex = lists.findIndex(list => list.uid === destination.droppableId);

        if (sourceListIndex === -1 || destinationListIndex === -1) {
            console.error('List not found');
            return;
        }

        const sourceList = lists[sourceListIndex];
        const destinationList = lists[destinationListIndex];

        if (!sourceList.cards || !destinationList.cards) {
            console.error('Cards array not found in one of the lists');
            return;
        }

        const sourceCardsCopy = Array.from(sourceList.cards);
        const destinationCardsCopy = Array.from(destinationList.cards);

        const [movedCard] = sourceCardsCopy.splice(source.index, 1);

        if (!movedCard) {
            console.error('No card moved');
            return;
        }

        destinationCardsCopy.splice(destination.index, 0, movedCard);

        const newLists = [...lists];
        newLists[sourceListIndex] = { ...sourceList, cards: sourceCardsCopy };
        newLists[destinationListIndex] = { ...destinationList, cards: destinationCardsCopy };

        setLists(newLists);
    };

    return (
        <div className="board-container">
            <button onClick={() => setIsModalOpen(true)} className="new-list-button">Nuova Lista</button>
            <DragDropContext onDragStart={onDragStart} onDragEnd={onDragEnd}>
                <div className="lists-container">
                    {lists.map((list) => (
                        <List
                            key={list.uid}
                            listUid={list.uid}
                            title={list.name}
                            cards={list.cards}
                            onAddCard={handleAddCard}
                            onEditCard={handleEditCard}
                            onDeleteCard={handleDeleteCard}
                        />
                    ))}
                </div>
            </DragDropContext>
        </div>
    );
};

export default Board;
