import React from 'react';
import './Home.css';



const Home: React.FC = () => {
  

   

    return (
        <div className="board-container">
            
        </div>
    );
};

export default Home;
