import React from 'react';
import './SideBar.css';

const Sidebar: React.FC = () => {
    return (
        <div className="sidebar">
            {/* Aggiungi elementi della sidebar qui */}
        </div>
    );
};

export default Sidebar;
